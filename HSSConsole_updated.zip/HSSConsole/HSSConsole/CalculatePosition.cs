﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Windows.Media.Imaging;
using System.Windows.Controls;

namespace HSSConsole
{
    class CalculatePosition
    {
        /// <summary>
        /// This method returns the block number in the main video image of the console.
        /// </summary>
        /// <param name="position"></param>
        /// <param name="mainVideoElement"></param>
        /// <returns></returns>
        public int returnPosition(System.Windows.Point position, MediaElement mainVideoElement)
        {
            if (((position.X > 0) && position.X < mainVideoElement.ActualWidth / 3) && ((position.Y > 0) && (position.Y < mainVideoElement.ActualHeight / 3)))
            {
               return 1;// Move Top-Left

            }
            else if (((position.X > mainVideoElement.ActualWidth / 3) && (position.X < mainVideoElement.ActualWidth * (2.0 / 3.0))) && ((position.Y > 0) && (position.Y < mainVideoElement.ActualHeight / 3)))
            {
                return 2;// Move Top
            }
            else if (((position.X > mainVideoElement.ActualWidth * (2.0 / 3.0)) && (position.X < mainVideoElement.ActualWidth)) && ((position.Y > 0) && position.Y < mainVideoElement.ActualHeight / 3))
            {
                return 3;// Move Top-Right
            }
            else if (((position.X > 0) && (position.X < mainVideoElement.ActualWidth / 3)) && ((position.Y > mainVideoElement.ActualHeight / 3) && (position.Y < mainVideoElement.ActualHeight * (2.0 / 3.0))))
            {
                return 4;// Move Left
            }

            else if (((position.X > mainVideoElement.ActualWidth / 3) && (position.X < mainVideoElement.ActualWidth * (2.0 / 3.0))) && (((position.Y > mainVideoElement.ActualHeight / 3) && position.Y < mainVideoElement.ActualHeight * (2.0 / 3.0))))
            {
                return 5;// Move Nowwhere
            }
            else if (((position.X > mainVideoElement.ActualWidth * (2.0 / 3.0)) && (position.X < mainVideoElement.ActualWidth)) && ((position.Y > mainVideoElement.ActualHeight / 3) && (position.Y < mainVideoElement.ActualHeight * (2.0 / 3.0))))
            {
                return 6;// Move Right
            }
            else if ((position.X > 0 && (position.X < mainVideoElement.ActualWidth / 3)) && (((position.Y > mainVideoElement.ActualHeight * (2.0 / 3.0))) && (position.Y < mainVideoElement.ActualHeight)))
            {
                return 7;// Move Bottom-Left
            }
            else if (((position.X > mainVideoElement.ActualWidth / 3) && (position.X < mainVideoElement.ActualWidth * (2.0 / 3.0))) && ((position.Y > mainVideoElement.ActualHeight * (2.0 / 3.0)) && (position.Y < mainVideoElement.ActualHeight)))
            {
                return 8;// Move Bottom
            }

            else if (((position.X > mainVideoElement.ActualWidth * (2.0 / 3.0)) && (position.X < mainVideoElement.ActualWidth)) && ((position.Y > mainVideoElement.ActualHeight * (2.0 / 3.0)) && (position.Y < mainVideoElement.ActualHeight)))
            {
                return 9;// Move Bottom-Right
            }

            else
            {
                return -1;
            }
        }
    }
}
