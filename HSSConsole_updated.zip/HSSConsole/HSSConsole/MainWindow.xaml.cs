﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OpenCvSharp;
using System.Drawing;
using System.IO;
using System.Diagnostics;



namespace HSSConsole
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml.
    ///
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
            

        }
        /// <summary>
        /// This is code for practice using the OpenCV wwrapper OpenCVSharp.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /*private void MyButton_Click(object sender, RoutedEventArgs e)
        {
           // ColorName = "Red";
            IplImage frame = Cv.LoadImage("Twitter.jpg", LoadMode.Unchanged);
            IplImage[] crop_frame = new IplImage[10];
            CvCapture capture = null;
            int key = 0;
            // capture = Cv.CreateFileCapture("Twitter.jpg");

            /* always check 
            if (capture != null) //change this to if(capture == null)
            {
                Console.WriteLine("Unable to Load");

            }

            while (key != 'q')
            {
                //frame = Cv.QueryFrame(capture);

                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        CvRect rect = new CvRect(i + (i * frame.Width) / 3, j + (j * frame.Height) / 3, frame.Width / 3, frame.Height / 3);
                        Cv.SetImageROI(frame, rect);
                        crop_frame[i * 3 + j] = Cv.CreateImage(Cv.GetSize(frame), frame.Depth, frame.NChannels);
                        Cv.Copy(frame, crop_frame[i * 3 + j]);
                        Cv.ResetImageROI(frame);
                    }


                }
                /* saving the image to the local disk
                Cv.SaveImage("Images/out.jpeg", frame);

                //System.Windows.Controls.Image img = new System.Windows.Controls.Image();
                BitmapImage logo = new BitmapImage();
                logo.BeginInit();
                logo.UriSource = new Uri("C:\\Users\\Hansraj\\Documents\\Visual Studio 2010\\Projects\\HSSConsole\\HSSConsole\\bin\\Debug\\Images\\out.jpeg");
                logo.EndInit();

                img.Source = logo;
                /*button.content
                MyButton.Content = img;


                for (int i = 0; i < 9; i++)
                {
                    Cv.SaveImage("Images/" + i + ".jpeg", crop_frame[i]);
                    Cv.NamedWindow(" " + i + " ", WindowMode.None);
                    Cv.ShowImage(" " + i + " ", crop_frame[i]);

                     logo = new BitmapImage();
                    logo.BeginInit();
                    logo.UriSource = new Uri("C:\\Users\\Hansraj\\Documents\\Visual Studio 2010\\Projects\\HSSConsole\\HSSConsole\\bin\\Debug\\Images\\"+i+".jpeg");
                    logo.EndInit();

                    img.Source = logo;
                    /*button.content
                    MyButton.Content = img;
                    /*System.Windows.Controls.Image img = new System.Windows.Controls.Image();
                    img.Source = CreateImage( "Images/" + i + ".jpeg");
                    img.VerticalAlignment = VerticalAlignment.Center; 
                    img.Margin = new Thickness(0, 0, 2, 0);
                    img.Source = CreateImage("Images/" + i + ".jpeg");
                    MyButton.Content = img;

                }
                    Cv.WaitKey();
            }



            Cv.DestroyWindow("result");
            Cv.ReleaseImage(frame);
            
            
        }*/
      



        /// <summary>
        /// This method is used to create a Bitmap Image from the path given to the method as input.
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>



        public static System.Windows.Media.Imaging.BitmapImage CreateImage(string path)
        {
            System.Windows.Media.Imaging.BitmapImage myBitmapImage = new System.Windows.Media.Imaging.BitmapImage(); myBitmapImage.BeginInit();
            try
            {
                myBitmapImage.UriSource = new Uri(path, UriKind.Relative); // bitmapImage.UriSource = new Uri("myIcon.ico", UriKind.Relative); 
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message.ToString());
            }
            myBitmapImage.EndInit();
            return myBitmapImage;
        }



        private void mediaElement1_LostMouseCapture(object sender, MouseEventArgs e)
        {

            
        }
        
        
        
        /// <summary>
        /// This method is used to get the position of the mouse or may be touch coordinates in the touch input panel.
        /// It calculates the position of the Mouse capture and returns the block in which the mouse is captured.Then
        /// the appropriate method can be called from the below conditions.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mediaElement1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Point position = e.GetPosition(mediaElement1);
            Debug.WriteLine(position);
            
            CalculatePosition calculatePosition = new CalculatePosition();
            int returnedPosition = calculatePosition.returnPosition(position,mediaElement1);
           
            /* Rect[][] q = new Rect[3][];
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    q[i][j] = new Rect(new System.Windows.Point(x, y), new System.Windows.Size(mediaElement1.ActualWidth / 3, mediaElement1.ActualHeight / 3));
                    x = x + mediaElement1.ActualWidth / 3;

                }
                x = 0;
                y = y + mediaElement1.ActualHeight / 3;

            }
            
            */
            
            switch (returnedPosition)
            {
                case 1:
                    Debug.Write("1");
                    break;
                case 2:
                    Debug.Write("2");
                    break;
                case 3:
                    Debug.Write("3");
                    break;
                case 4:
                    Debug.Write("4");
                    break;
                case 5:
                    Debug.Write("5");
                    break;
                case 6:
                    Debug.Write("6");
                    break;
                case 7:
                    Debug.Write("7");
                    break;
                case 8:
                    Debug.Write("8");
                    break;
                case 9:
                    Debug.Write("9");
                    break;
                default:
                    break;
            }
            
            

        }

    }
}
